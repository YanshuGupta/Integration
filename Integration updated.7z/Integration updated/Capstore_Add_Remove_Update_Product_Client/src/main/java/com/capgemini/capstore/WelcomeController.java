package com.capgemini.capstore;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.ChangePasswordDummy;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Offer;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.User;

@Controller
public class WelcomeController {

	private Product tempProduct;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Autowired
	private HttpSession session;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	RestTemplate rest;
	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	@RequestMapping(value = "/")
	public String getResponse(ModelMap map) {
		// request.getSession().invalidate();
//		System.out.println(session.getAttribute("user"));
//		session = request.getSession(false);
//		User user;// = new User();
		User user = (User) session.getAttribute("user");
		if (session != null && user != null ) {
			/*
			 * session = request.getSession(); User user =
			 * (User)session.getAttribute("user"); System.out.println(user.toString());
			 */if (user.getRole().equalsIgnoreCase("customer")) {
				return "Home";
			} else if (user.getRole().equalsIgnoreCase("merchant")) {
				return "MerchantHome";
			} else {
				return "Admin";
			}
		}
		return "Home";

	}

	@RequestMapping("/MerchantHome")
	public String merchantHome(ModelMap map) {
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "MerchantHome";
	}

	@RequestMapping("/AddProductsByMerchant")
	public String addProductsByMerchant(ModelMap map) {
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "AddProductsByMerchant";
	}

	@RequestMapping("/DeleteProductsByMerchant")
	public String deleteProductsByMerchant(ModelMap map) {
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "DeleteProductsByMerchant";
	}

	@RequestMapping("/UpdateProductByMerchant")
	public String updateProductByMerchant(ModelMap map) {
		if (request.getSession(false) == null) {
			return "Home";
		}
		return "UpdateProductByMerchant";
	}

	@RequestMapping(value = "/findProductById", method = RequestMethod.POST, produces = "application/json")
	public String findProduct(ModelMap map) {
		if (request.getSession(false) == null) {
			return "Home";
		}
		String merchantEmail = ((User) request.getSession().getAttribute("user")).getEmailId();// "yanshu@gupta.com";
		String productId = request.getParameter("productId");
		tempProduct = rest.postForObject("http://localhost:8092/getProduct/" + productId + "/" + merchantEmail, null,
				Product.class);
		return "UpdateProductDetailsByMerchant";
	}

	@RequestMapping("/ShowProductsForMerchant")
	public String showProductsForMerchant(ModelMap map) {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		
		String merchantEmail = user.getEmailId();//"yanshu@gupta.com";

		List<Product> list = rest.postForObject("http://localhost:8092/getAllProducts/" + merchantEmail, null,
				List.class);
		map.addAttribute("list", list);
		System.out.println(list);
		return "ShowProductsForMerchant";
	}

	@RequestMapping(value = "/fileinsertmerchant", method = RequestMethod.POST, produces = "application/json")
	public String addProduct() {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		
		String merchantEmail = user.getEmailId();//"yanshu@gupta.com";

//		System.out.println(product);
		Product product = new Product();
		String productName = request.getParameter("productName");
//		String productImageUrl = request.getParameter("productImageUrl");
		String productCategory = request.getParameter("productCategory");
		String productBrand = request.getParameter("productBrand");
		String productModel = request.getParameter("productModel");
		String productType = request.getParameter("productType");
//		String productFeature = request.getParameter("productFeature");
		double productPrice = Double.parseDouble(request.getParameter("productPrice"));

		product.setProductBrand(productBrand);
		product.setProductCategory(productCategory);
		product.setProductFeature("feature");
		product.setProductImageUrl("Image url");
		product.setProductModel(productModel);
		product.setProductName(productName);
		product.setProductType(productType);
		product.setProductPrice(productPrice);

		System.out.println(product);

		RestResponseAddProduct restRes = new RestResponseAddProduct();
		restRes.setProduct(product);

		String str = rest.postForObject("http://localhost:8092/addProduct/" + merchantEmail, product, String.class);
		return str;
//		return "MerchantHome";
	}

	@RequestMapping(value = "/reduceproductbymerchant", method = RequestMethod.POST, produces = "application/json")
	public String deleteProduct() {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		
		String merchantEmail = user.getEmailId();//"yanshu@gupta.com";
		String productId = request.getParameter("productId");
		String str = rest.postForObject("http://localhost:8092/removeProduct/" + productId + "/" + merchantEmail, null,
				String.class);
		if (str.equals("success")) {
			return "DeleteProductsByMerchant";
		} else {
			// set error msg
			return "DeleteProductsByMerchant";
		}
	}

	@RequestMapping(value = "/fileupdatemerchant", method = RequestMethod.POST, produces = "application/json")
	public String updateMerchantProduct() {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		
		String merchantEmail = user.getEmailId();//"yanshu@gupta.com";
//		String merchantEmail = "yanshu@gupta.com";
		Product product = new Product();
		String productName = request.getParameter("productName");
//		String productImageUrl = request.getParameter("productImageUrl");
		String productCategory = request.getParameter("productCategory");
		String productBrand = request.getParameter("productBrand");
		String productModel = request.getParameter("productModel");
		String productType = request.getParameter("productType");
//		String productFeature = request.getParameter("productFeature");
		double productPrice = Double.parseDouble(request.getParameter("productPrice"));

		product.setProductBrand(productBrand);
		product.setProductCategory(productCategory);
		product.setProductFeature("feature");
		product.setProductImageUrl("Image url");
		product.setProductModel(productModel);
		product.setProductName(productName);
		product.setProductType(productType);
		product.setProductPrice(productPrice);
		product.setProductId(tempProduct.getProductId());

		System.out.println(product);

		RestResponseAddProduct restRes = new RestResponseAddProduct();
		restRes.setProduct(product);

		String str = rest.postForObject("http://localhost:8092/updateProduct/" + merchantEmail, product, String.class);
		// msg -> Product updated success
		return str;
	}

	@RequestMapping(value = "/Login")
	public String getSignUp() {
		if (session == null) {
			return "Login";
		}
//		else {
//			return "Home";
//		}
//		
//		String merchantEmail = user.getEmailId();//"yanshu@gupta.com";
		return "Login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	public String enterSignUpDetails() {
		// if
		/* (!(request.getSession(false) == null)) */ {
			// User user =
		}
		// (User)request.getSession().getAttribute("user"); //
		// if(user.getRole().equalsIgnoreCase("customer")) { // return "Home"; // } //
		// else if(user.getRole().equalsIgnoreCase("merchant")) { // return
		// "MerchantHome"; // } // else { // return "Admin"; // } // }
		User user = new User();
		String email = request.getParameter("email");
		user.setEmailId(email);
		String password = request.getParameter("password");
		user.setPassword(password);
		String role = request.getParameter("a3");
		System.out.println(user.getEmailId() + user.getPassword());
		user.setRole(role);
		session = request.getSession(true);
		session.setAttribute("user", user);
		String str = rest.postForObject("http://localhost:8092/logIn", user, String.class);
		return str;
	}

	@RequestMapping(value = "/Ask")
	public String getSignUpDetails() {

		return "Ask";
	}

	@RequestMapping(value = "/ForgotPassword")
	public String forgotPassword() {

		return "ForgotPassword";
	}

	@RequestMapping(value = "/ForgotPasswordd", method = RequestMethod.POST, produces = "application/json")
	public String afterForgotPassword() {

		User user = new User();
		String email = request.getParameter("n4");
		String securityQuestion = request.getParameter("a4");
		String securityAnswer = request.getParameter("n2");
		user.setEmailId(email);
		user.setSecurityAnswer(securityAnswer);
		user.setSecurityQuestion(securityQuestion);
		HttpSession session = request.getSession(true);
		session.setAttribute("user", user);
		String str = rest.postForObject("http://localhost:8092/forgotPassword", user, String.class);
		return str;

	}

	@RequestMapping(value = "/Home", method = RequestMethod.POST, produces = "application/json")
	public String successfullChagePassword() {

		String password = request.getParameter("n3");
		String confirmPassword = request.getParameter("n4");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		user.setPassword(password);

		if (password.equals(confirmPassword)) {

			String str = rest.postForObject("http://localhost:8092/passwordChangePage", user, String.class);
			return str;

		}

		return "ForgotPasswordConfirmation";
	}

	@RequestMapping(value = "/SignUp", method = RequestMethod.POST, produces = "application/json")
	public String validateSignUpDetails() {

		User user = new User();
		String email = request.getParameter("a1");
		user.setEmailId(email);
		String password = request.getParameter("a2");
		user.setPassword(password);
		String role = request.getParameter("a3");
		user.setRole(role);
		String securityQuestion = request.getParameter("a4");
		user.setSecurityQuestion(securityQuestion);
		String securityAnswer = request.getParameter("a5");
		user.setSecurityAnswer(securityAnswer);
		String str = rest.postForObject("http://localhost:8092/signUp", user, String.class);
		if (str.equals("ask")) {
			// set msg
		}
		return str;
	}

	@RequestMapping(value = "/Customer_OTP", method = RequestMethod.POST, produces = "application/json")
	public String enterMoreSignUpDetailsCustomer() {

		Customer customer = new Customer();
		String name = request.getParameter("n2");
		String email = request.getParameter("n5");
		String mobileNo = request.getParameter("n4");
		String address = request.getParameter("n8");
		String pincode = request.getParameter("n6");
		customer.setCustomerAddress(address);
		customer.setCustomerEmail(email);
		customer.setCustomerMobileNumber(mobileNo);
		customer.setCustomerName(name);
		customer.setCustomerPincode(pincode);
		String str = rest.postForObject("http://localhost:8092/registerCustomer", customer, String.class);
		return str;

	}

	@RequestMapping(value = "/Merchant_OTP", method = RequestMethod.POST, produces = "application/json")
	public String enterMoreSignUpDetailsMerchant() {

		Merchant merchant = new Merchant();
		String name = request.getParameter("n1");
		String email = request.getParameter("n2");
		String storeName = request.getParameter("n3");
		String mobileNo = request.getParameter("n4");
		String address = request.getParameter("n5");
		merchant.setMerchantAddress(address);
		merchant.setMerchantEmail(email);
		merchant.setMerchantMobileNumber(mobileNo);
		merchant.setMerchantName(name);
		merchant.setMerchantStoreName(storeName);
		String str = rest.postForObject("http://localhost:8092/registerMerchant", merchant, String.class);
		return str;
	}

	@RequestMapping(value = "/ChangePassword")
	public String getChangePasswordPage() {
		return "ChangePassword";
	}

	@RequestMapping("/logOut")
	public String logOut() {

		
		session.invalidate();
		return "Home";

	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public String changePasword() {

		String str = null;
		String currentPassword = request.getParameter("n2");
		String newPassword = request.getParameter("n3");
		String confirmNewPassword = request.getParameter("n4");
		ChangePasswordDummy dummy = new ChangePasswordDummy();
		HttpSession session = request.getSession(true);
		User user = (User) session.getAttribute("user");
		System.out.println(user);
		dummy.setEmail(user.getEmailId());
		dummy.setOldPassword(currentPassword);
		dummy.setNewPassword(newPassword);
		dummy.setRole(user.getRole());
		System.out.println("hii");
		if (newPassword.equals(confirmNewPassword)) {
			str = rest.postForObject("http://localhost:8092/changePasswordd", dummy, String.class);
		}
		return str;
	}
	@RequestMapping("/CheckOrdersByMerchant")
	public String checkOrdersByMerchant(ModelMap map) {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		String merchantEmail = user.getEmailId();//"yanshu@gupta.com";
		List<Order> orderList = rest.postForObject("http://localhost:8092/findOrdersByMerchant/"+merchantEmail, null, List.class);
		map.addAttribute("list", orderList);
		return "CheckOrdersByMerchant";
	}
	@RequestMapping("/DiscountByMerchant")
	public String discountByMerchant(ModelMap map) {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		return "DiscountByMerchant";
	}
	@RequestMapping("/addDiscount")
	public String addDiscount(ModelMap map) {
		if (session == null) {
			return "Home";
		}
		User user = (User)request.getSession().getAttribute("user");
//		if(!(user.getRole().equals("MERCHANT"))) {
//			return "Home";
//		}
		Offer offer = new Offer();
		String merchantEmail = ((User) request.getSession().getAttribute("user")).getEmailId();// "yanshu@gupta.com";
		String productId = request.getParameter("prodcutId");
		System.out.println(productId+"hii");
		tempProduct = rest.postForObject("http://localhost:8092/getProduct/" + productId + "/" + merchantEmail, null,
				Product.class);
		offer.setProduct(tempProduct);
//		System.out.println(tempProduct.toString());
		Merchant merchant = rest.postForObject("http://localhost:8092/getMerchant/" + merchantEmail, null,
				Merchant.class);
		offer.setMerchant(merchant);
//		System.out.println(merchant.toString());
		offer.setOfferDescription(request.getParameter("offerDescription"));
		offer.setDiscountOffered(Double.parseDouble(request.getParameter("discountOffered")));
//		Date startDate=new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("offerStartDate"));  
//		Date endDate=new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("offerEndDate"));  
		offer.setOfferStartDate(request.getParameter("offerStartDate"));
		offer.setOfferEndDate(request.getParameter("offerEndDate"));
		offer.setSoftDelete("A");
		System.out.println(offer.toString());
		rest.postForObject("http://localhost:8092/addDiscount", offer, Void.class);
//		set added msg
		return "DiscountByMerchant";
	}
	@RequestMapping("/MerchantFeedbackMerchant")
	public String merchantFeedbackMerchant(ModelMap map) {
		if (session == null) {
			return "Home";
		}
		return "MerchantFeedbackMerchant";
	}
	@RequestMapping("/MerchantFeedbackProduct")
	public String merchantFeedbackProduct(ModelMap map) {
		if (session == null) {
			return "Home";
		}
		return "MerchantFeedbackProduct";
	}
	

	
}
