package com.capgemini.capstore.main.service;

public interface ICapStoreCustomerService {

}
