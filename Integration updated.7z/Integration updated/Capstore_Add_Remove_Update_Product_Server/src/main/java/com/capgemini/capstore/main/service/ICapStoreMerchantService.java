package com.capgemini.capstore.main.service;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;

public interface ICapStoreMerchantService {

	void registerMerchant(Merchant merchant);

	void registerCustomer(Customer customer);

}
