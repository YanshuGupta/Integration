package com.capgemini.capstore.main.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.ChangePasswordDummy;
import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.beans.User;
import com.capgemini.capstore.main.service.ICapStoreAdminService;
import com.capgemini.capstore.main.service.ICapStoreCommonService;
import com.capgemini.capstore.main.service.ICapStoreCustomerService;
import com.capgemini.capstore.main.service.ICapStoreMerchantService;

@RestController
public class URIController {

	@Autowired
	ICapStoreCommonService commonService;

	@Autowired
	ICapStoreAdminService adminService;

	@Autowired
	ICapStoreMerchantService merchantService;

	@Autowired
	ICapStoreCustomerService customerService;
	
	
	
	@RequestMapping("/")
	public String abc()
	{
		return "kuch bhi";
	}
	
	
	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public String logIn(@RequestBody User user, HttpServletRequest request) {
		
		boolean result = false;
		try {
			
			result = commonService.ValidateLogIn(user);
			System.out.println("Result"+result);
			if(result) {
							
				if (user.getRole().equals("ADMIN")) {
					
					return "Admin";
					
				}
				if (user.getRole().equals("MERCHANT")) {
									
					return "MerchantHome";				
									
				}
				if (user.getRole().equals("CUSTOMER")) {
					
					return "HomeCustomer";
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// set error msg
		return "Home";
	}

	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logOut(HttpServletRequest request) {
		
		request.getSession().invalidate();
		return "indexPage";
		
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String forgotPassword(@RequestBody User user, HttpServletRequest request) {
		
		User result = null;
		
		if ((result = commonService.isValidEmail(user.getEmailId())) != null) {
			
			if(user.getSecurityQuestion().equals(result.getSecurityQuestion()) && user.getSecurityAnswer().equals(result.getSecurityAnswer())) {
				
				return "ForgotPasswordConfirmation";
				
			}
			
		}
		
		return "ForgotPassword";
	}

	@RequestMapping(value = "/passwordChangePage", method = RequestMethod.POST)
	public String passwordChangePage(@RequestBody User user, HttpServletRequest request) {
		
		commonService.updatePassword(user.getEmailId(), user.getPassword());
		return "Home";
		
	}

	@RequestMapping(value = "/changePasswordd", method = RequestMethod.POST)
	public String changePassword(@RequestBody ChangePasswordDummy changePassword,	HttpServletRequest request) {
		
		if (commonService.changePassword(changePassword.getEmail(),changePassword.getOldPassword(),changePassword.getNewPassword())) {
			if(changePassword.getRole().equals("CUSTOMER"))
				return "HomeCustomer";
			if(changePassword.getRole().equals("MERCHANT"))
				return "MerchantHome";
			if(changePassword.getRole().equals("ADMIN"))
				return "Admin";
		}
		
		return "changePassword";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String signUp(@Valid @RequestBody User user) {
		
		System.out.println(user);
	
		if (commonService.ValidateUserDetails(user)) {
			if(user.getRole().equalsIgnoreCase("CUSTOMER"))
				return "CustomerSignUp";
			if(user.getRole().equalsIgnoreCase("MERCHANT"))
				return "MerchantSignUp";
		}
			// set error msg details are incorrect
			return "ask";
	}
	
	@RequestMapping(value = "/registerMerchant", method = RequestMethod.POST)
	public String finalRegistrationForMerchant(@RequestBody Merchant merchant) {
		merchant.setMerchantRating(1);
		merchant.setProducts(new ArrayList<Product>());
//		System.out.println(merchant);
		merchantService.registerMerchant(merchant);
		
		return "Login";
		
	}

	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public String finalRegistrationForCustomer(@RequestBody Customer customer) {
		System.out.println(customer);
		merchantService.registerCustomer(customer);
		
		return "Login";
		
	}
	
}
