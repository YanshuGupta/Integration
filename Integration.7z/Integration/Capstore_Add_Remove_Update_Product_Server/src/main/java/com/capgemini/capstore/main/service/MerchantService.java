package com.capgemini.capstore.main.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreOrder;
import com.capgemini.capstore.main.dao.CapStoreProduct;

@Service
public class MerchantService implements IMerchantService {

	@Autowired
	CapStoreMerchant merchantRepo;

	@Autowired
	CapStoreProduct productRepo;

	@Autowired
	CapStoreCustomer customerRepo;
	
	@Autowired
	CapStoreOrder orderRepo;
	
	@Override
	public void registerMerchant(Merchant merchant) {
		
		merchantRepo.save(merchant);
	}

	@Override
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
		
	}
	
	@Override
	public Product getProduct(int productId, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		for (Product product : merchant.getProducts()) {
			if (product.getProductId() == productId) {
				return product;
			}
		}
		return null;
	}
	
	@Override
	public List<Product> getAllProducts(String merchantEmail) {
		
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		return merchant.getProducts();
	}

	@Override
	public Product addProduct(Product product, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);

		List<Product> productList = merchant.getProducts();
		productList.add(product);
		merchantRepo.save(merchant);
		return product;
	}

	@Override
	public Product updateProduct(Product product, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		for (Product productObj : merchant.getProducts()) {
			if (product.getProductId() == productObj.getProductId()) {
				productRepo.save(product);
				merchantRepo.save(merchant);
				return product;
			}
		}
		return null;
	}

	@Override
	public boolean removeProduct(int productId, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		Iterator<Product> itr = merchant.getProducts().iterator();
		while (itr.hasNext()) {
			Product product = itr.next();
			if (product.getProductId() == productId) {
				itr.remove();
				productRepo.deleteById(productId);
				merchantRepo.save(merchant);
				return true;
			}
		}
		return false;
	}

	@Override
	public List<Order> findOrdersByMerchant(String merchantEmail) {
		
		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		List<Order> orderList = orderRepo.findByMerchant(merchant);
		return orderList;
	}


}
