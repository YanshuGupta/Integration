package com.capgemini.capstore.beans;

import java.util.Date;

public class Offer {

	private int offerId;
	
	private Merchant merchant;
	
	private Product product;

	private String offerDescription;

	private String offerStartDate;
	
	private String offerEndDate;
	
	private double discountOffered;
	
	private String softDelete;

	public int getOfferId() {
		return offerId;
	}

	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getOfferDescription() {
		return offerDescription;
	}

	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}

	

	public String getOfferStartDate() {
		return offerStartDate;
	}

	public void setOfferStartDate(String offerStartDate) {
		this.offerStartDate = offerStartDate;
	}

	public String getOfferEndDate() {
		return offerEndDate;
	}

	public void setOfferEndDate(String offerEndDate) {
		this.offerEndDate = offerEndDate;
	}

	public double getDiscountOffered() {
		return discountOffered;
	}

	public void setDiscountOffered(double discountOffered) {
		this.discountOffered = discountOffered;
	}

	public String getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	@Override
	public String toString() {
		return "Offer [offerId=" + offerId + ", merchant=" + merchant + ", product=" + product + ", offerDescription="
				+ offerDescription + ", offerStartDate=" + offerStartDate + ", offerEndDate=" + offerEndDate
				+ ", discountOffered=" + discountOffered + ", softDelete=" + softDelete + "]";
	}

}
