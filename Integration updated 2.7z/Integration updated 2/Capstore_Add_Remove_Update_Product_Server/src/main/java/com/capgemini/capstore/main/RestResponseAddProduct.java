package com.capgemini.capstore.main;

import org.springframework.web.multipart.MultipartFile;

import com.capgemini.capstore.main.beans.Product;

public class RestResponseAddProduct {
	
	private Product product;
	private MultipartFile urls;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public RestResponseAddProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MultipartFile getUrls() {
		return urls;
	}

	public void setUrls(MultipartFile urls) {
		this.urls = urls;
	}

	@Override
	public String toString() {
		return "RestResponseAddProduct [product=" + product + ", urls=" + urls + "]";
	}

	
	
	

}
